function addTokens(input, tokens) {
  if (typeof input !== "string") {
    throw new Error("Invalid input");
  }

  if (input.length < 6) {
    throw new Error("Input should have at least 6 characters");
  }

  for (let i = 0; i < tokens.length; i++) {
    if (!(typeof tokens[i].tokenName === "string")) {
      throw new Error("Invalid array format");
    }
  }

  if (!input.includes("...")) {
    return input;
  }

  for (let i = 0; i < tokens.length; i++) {
    let a = tokens[i]["tokenName"];
    let b = "${" + a + "}";
    let c = "...";
    let position = input.indexOf("...");
    if (position !== -1) {
      input = input.replace(c, b);
    }
  }
  return input;
}

const app = {
  addTokens: addTokens,
};

module.exports = app;

// input este un string ce poate sa contina "...". De exemplu: Subsemnatul ..., dominiciliat in ...;
// tokens un vector de tokenuri.
// Functia trebuie sa inlocuiasca toate ... din input cu valorile corespunzatoare din tokens sub urmatorul format ${tokenName}, in ordinea in care exista in vector;

// input trebuie sa fie de tip string. Daca alt tip este pasat ca si parametru aruncati Error cu mesajul Input should be a string; (0.5 pts)
// input trebuie sa aiba cel putin 6 caractere ca si lungime. Daca dimensiunea input-ului este mai mica de 6, aruncati Error cu mesajul Input should have at least 6 characters; (0.5 pts)
// tokens este un vector de elemente cu urmatorul format: {tokenName: string}. Daca urmatorul format nu este respectat, aruncati Error cu urmatorul mesaj Invalid array format; (0.5 pts)
// Daca input nu contine ... returnati valoarea initiala a input-ului; (0.5 pts)
// Daca input contine ..., inlocuiti-le cu valorile specifice si returnati noul input; (0.5 pts)
